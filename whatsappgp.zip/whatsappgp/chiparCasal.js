
function chiparCasal(participants) {
  if (!participants || participants.length < 2) {
    return '❌ Não há participantes suficientes para formar um casal!';
  }

  
  const formatMention = (jid) => `@${jid.split('@')[0]}`;

  
  const shuffled = [...participants].sort(() => Math.random() - 0.5);
  const [first, second] = shuffled.slice(0, 2).map(formatMention);

 
  const gifts = [
    '🌹 Buquê de Rosas Digitais',
    '💌 Poema de Amor Personalizado',
    '🎁 Caixa-surpresa Virtual',
    '🍫 Doces Virtuais'
  ];

 
  const messages = [
    `💘 Alerta de Compatibilidade! ${first} & ${second}\nO algoritmo do amor os uniu!\nPresente: ${randomChoice(gifts)}`,
    `✨ Casal Perfeito: ${first} + ${second}\nSua química é impressionante!\nMimo: ${randomChoice(gifts)}`,
    `🔥 Combinação Explosiva!\n${first} ❤️ ${second}\nPresente especial: ${randomChoice(gifts)}`,
    `💞 Par Ideal Detectado!\n${first} e ${second} são puro romance!\nSurpresa: ${randomChoice(gifts)}`
  ];

  return randomChoice(messages);
}


function randomChoice(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

module.exports = { chiparCasal };