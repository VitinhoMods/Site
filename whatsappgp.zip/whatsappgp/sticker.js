const fs = require('fs');
const { tmpdir } = require('os');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { writeFile } = require('fs/promises');
const sharp = require('sharp');
const { default: axios } = require('axios');

const tempFolder = path.join(tmpdir(), 'whatsapp-stickers');


if (!fs.existsSync(tempFolder)) {
  fs.mkdirSync(tempFolder, { recursive: true });
}

const downloadMedia = async (message, mimetype) => {
  try {
    
    let messageType;
    let messageInfo;
    
    if (message.message.imageMessage) {
      messageType = 'image';
      messageInfo = message.message.imageMessage;
    } else if (message.message.videoMessage) {
      messageType = 'video';
      messageInfo = message.message.videoMessage;
    } else if (message.message.documentMessage) {
      messageType = 'document';
      messageInfo = message.message.documentMessage;
    } else if (message.message.stickerMessage) {
      messageType = 'sticker';
      messageInfo = message.message.stickerMessage;
    } else {
      throw new Error('Tipo de mídia não suportado');
    }
    
    
    const stream = await downloadContentFromMessage(messageInfo, messageType);
    
    
    let buffer = Buffer.from([]);
    
    
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }
    
    
    const filename = `${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const fileExtension = mimetype.split('/')[1];
    const filePath = path.join(tempFolder, `${filename}.${fileExtension}`);
    
    
    await writeFile(filePath, buffer);
    
    return { filePath, buffer };
  } catch (error) {
    console.error('Erro ao baixar mídia:', error);
    throw error;
  }
};

const createImageSticker = async (imageBuffer) => {
  try {
    
    const webpBuffer = await sharp(imageBuffer)
      .resize({
        width: 512,
        height: 512,
        fit: 'contain',
        background: { r: 0, g: 0, b: 0, alpha: 0 }
      })
      .webp()
      .toBuffer();
    
    return webpBuffer;
  } catch (error) {
    console.error('Erro ao criar sticker com Sharp:', error);
    throw error;
  }
};

const createStickerWithText = async (imageBuffer, text) => {
  try {
   
    const webpBuffer = await sharp(imageBuffer)
      .resize({
        width: 512, 
        height: 512,
        fit: 'contain',
        background: { r: 0, g: 0, b: 0, alpha: 0 }
      })
      
      .composite([{
        input: Buffer.from(
          `<svg width="512" height="512">
            <text x="50%" y="90%" font-family="sans-serif" font-size="24" fill="white" 
                  stroke="black" stroke-width="1" text-anchor="middle">${text}</text>
          </svg>`
        ),
        gravity: 'south'
      }])
      .webp()
      .toBuffer();
    
    return webpBuffer;
  } catch (error) {
    console.error('Erro ao criar sticker com texto:', error);
    throw error;
  }
};

const cleanTempFiles = (filePaths) => {
  filePaths.forEach(filePath => {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  });
};

const handleStickerCommands = async (sock, msg) => {
  try {
    const jid = msg.key.remoteJid;
    const isQuoted = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
    
   
    const textMessage = msg.message.conversation || 
                        msg.message.extendedTextMessage?.text || 
                        '';
    
    
    const [command, ...args] = textMessage.trim().split(' ');
    
    
    const filesToClean = [];
    
    
    if (['/sticker', '/s', '!sticker'].includes(command.toLowerCase())) {
      
      
      let mediaMessage;
      
      if (msg.message.imageMessage) {
       
        mediaMessage = msg;
      } else if (isQuoted && isQuoted.imageMessage) {
        
        mediaMessage = {
          key: msg.key,
          message: msg.message.extendedTextMessage.contextInfo.quotedMessage
        };
      } else if (msg.message.videoMessage || (isQuoted && isQuoted.videoMessage)) {
        
        await sock.sendMessage(jid, { 
          text: 'Desculpe, a conversão de vídeos para figurinhas não está disponível nesta versão. Por favor, envie apenas imagens.' 
        });
        return;
      } else {
      
        await sock.sendMessage(jid, { text: 'Envie ou responda a uma imagem com o comando /sticker' });
        return;
      }
      
      
      await sock.sendMessage(jid, { text: 'Criando figurinha... ⏳' });
      
      
      const { filePath, buffer } = await downloadMedia(mediaMessage, 'image/jpeg');
      filesToClean.push(filePath);
      
      
      const stickerBuffer = await createImageSticker(buffer);
      
      
      const stickerPath = path.join(tempFolder, `sticker-${Date.now()}.webp`);
      await writeFile(stickerPath, stickerBuffer);
      filesToClean.push(stickerPath);
      
      
      await sock.sendMessage(jid, { 
        sticker: { url: stickerPath }
      });
      
    } 
    
    else if (['/stext', '/st', '!stickertext'].includes(command.toLowerCase())) {
      const text = args.join(' ');
      
      if (!text) {
        await sock.sendMessage(jid, { text: 'Digite um texto após o comando. Ex: /stext Olá mundo!' });
        return;
      }
      
     
      let mediaMessage;
      
      if (msg.message.imageMessage) {
       
        mediaMessage = msg;
      } else if (isQuoted && isQuoted.imageMessage) {
        
        mediaMessage = {
          key: msg.key,
          message: msg.message.extendedTextMessage.contextInfo.quotedMessage
        };
      } else {
        
        await sock.sendMessage(jid, { text: 'Envie ou responda a uma imagem com o comando /stext' });
        return;
      }
      
      
      await sock.sendMessage(jid, { text: 'Criando figurinha com texto... ⏳' });
      
      
      const { filePath, buffer } = await downloadMedia(mediaMessage, 'image/jpeg');
      filesToClean.push(filePath);
      
      
      const stickerBuffer = await createStickerWithText(buffer, text);
      
      
      const stickerPath = path.join(tempFolder, `sticker-text-${Date.now()}.webp`);
      await writeFile(stickerPath, stickerBuffer);
      filesToClean.push(stickerPath);
      
      
      await sock.sendMessage(jid, {
        sticker: { url: stickerPath }
      });
      
    }
  
    else if (['/shelp', '/stickerhelp', '!shelp'].includes(command.toLowerCase())) {
      const helpText = `*Comandos de Figurinhas* 📝
      
*/sticker* ou */s* - Cria uma figurinha a partir de imagem
*/stext* ou */st* - Cria uma figurinha com texto (responda a uma imagem)
*/shelp* - Exibe esta ajuda de comandos de figurinhas

Nota: Nesta versão, apenas imagens são suportadas.`;
      
      await sock.sendMessage(jid, { text: helpText });
    }
    
    
    cleanTempFiles(filesToClean);
    
  } catch (error) {
    console.error('Erro ao processar comando de figurinha:', error);
    await sock.sendMessage(msg.key.remoteJid, { 
      text: 'Ocorreu um erro ao criar a figurinha. Tente novamente.' 
    });
  }
};

module.exports = {
  handleStickerCommands
};