const path = require('path');
const fs = require('fs');

const ALLOWED_LINKS_FILE = path.resolve(__dirname, 'allowedLinks.json');

let allowedLinks = {};

const loadAllowedLinks = () => {
  try {
    if (fs.existsSync(ALLOWED_LINKS_FILE)) {
      allowedLinks = JSON.parse(fs.readFileSync(ALLOWED_LINKS_FILE, 'utf8'));
    }
  } catch (error) {
    console.error('Erro ao carregar links permitidos:', error);
  }
};

const saveAllowedLinks = () => {
  fs.writeFileSync(ALLOWED_LINKS_FILE, JSON.stringify(allowedLinks, null, 2));
};

const addAllowedChannel = (groupId, channel) => {
  if (!allowedLinks[groupId]) {
    allowedLinks[groupId] = [];
  }
  
  const normalizedChannel = channel.startsWith('@') ? channel : `@${channel}`;
  if (!allowedLinks[groupId].includes(normalizedChannel)) {
    allowedLinks[groupId].push(normalizedChannel);
    saveAllowedLinks();
  }
};

const removeAllowedChannel = (groupId, channel) => {
  if (allowedLinks[groupId]) {
    const normalizedChannel = channel.startsWith('@') ? channel : `@${channel}`;
    allowedLinks[groupId] = allowedLinks[groupId].filter(c => c !== normalizedChannel);
    saveAllowedLinks();
  }
};

const getAllowedChannels = (groupId) => {
  return allowedLinks[groupId] || [];
};

module.exports = {
  loadAllowedLinks,
  addAllowedChannel,
  removeAllowedChannel,
  getAllowedChannels
};