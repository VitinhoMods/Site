const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const { Boom } = require('@hapi/boom');

const SCHEDULE_FILE = path.resolve(__dirname, 'groupSchedules.json');


let groupSchedules = {};


const loadSchedules = () => {
    try {
        if (fs.existsSync(SCHEDULE_FILE)) {
            const data = fs.readFileSync(SCHEDULE_FILE, 'utf8');
            groupSchedules = JSON.parse(data);
        }
    } catch (error) {
        console.error('Erro ao carregar agendamentos:', error);
    }
};


const saveSchedules = () => {
    try {
        fs.writeFileSync(SCHEDULE_FILE, JSON.stringify(groupSchedules, null, 2));
    } catch (error) {
        console.error('Erro ao salvar agendamentos:', error);
    }
};


const isValidTime = (time) => {
    return /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(time);
};


const timeToMinutes = (time) => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
};


const setGroupSchedule = (groupId, adminId, closeTime, openTime) => {
    groupSchedules[groupId] = {
        adminId,
        closeTime,
        openTime,
        isClosed: false
    };
    saveSchedules();
};


const getGroupSchedule = (groupId) => {
    return groupSchedules[groupId];
};


const removeGroupSchedule = (groupId) => {
    delete groupSchedules[groupId];
    saveSchedules();
};


const startScheduleChecker = (sock) => {
    cron.schedule('* * * * *', async () => { 
        const now = new Date();
        const currentMinutes = now.getHours() * 60 + now.getMinutes();

        for (const [groupId, schedule] of Object.entries(groupSchedules)) {
            const closeMinutes = timeToMinutes(schedule.closeTime);
            const openMinutes = timeToMinutes(schedule.openTime);

            try {
                if (!schedule.isClosed && currentMinutes >= closeMinutes) {
                    await sock.groupSettingUpdate(groupId, 'announcement');
                    schedule.isClosed = true;
                    await sock.sendMessage(groupId, {
                        text: `🚪 O grupo foi fechado!\nHorário de funcionamento: ${schedule.openTime} às ${schedule.closeTime}`
                    });
                } else if (schedule.isClosed && currentMinutes >= openMinutes) {
                    await sock.groupSettingUpdate(groupId, 'not_announcement');
                    schedule.isClosed = false;
                    await sock.sendMessage(groupId, {
                        text: `🚪 O grupo foi reaberto!\nNovo horário de fechamento: ${schedule.closeTime}`
                    });
                }
            } catch (error) {
                console.error(`Erro ao atualizar grupo ${groupId}:`, error);
                if (error.output?.statusCode === 403) {
                    removeGroupSchedule(groupId);
                }
            }
        }
        saveSchedules();
    });
};


const handleScheduleCommands = async (sock, msg) => {
    const jid = msg.key.remoteJid;
    const isGroup = jid.endsWith('@g.us');
    const sender = msg.key.participant || jid;

    if (isGroup) {
        const text = (msg.message.conversation || '').toLowerCase();
        
        if (text.startsWith('!fechar')) {
            try {
                const metadata = await sock.groupMetadata(jid);
                const isAdmin = metadata.participants.find(p => p.id === sender)?.admin;
                
                if (!isAdmin) {
                    return sock.sendMessage(jid, {
                        text: '⚠️ Apenas administradores podem configurar o horário!',
                        mentions: [sender]
                    });
                }

                await sock.sendMessage(sender, {
                    text: '⏰ *Configurar Horário do Grupo*\n\nEnvie o horário no formato:\n`Fechar: HH:MM\nAbrir: HH:MM`\n\nExemplo:\nFechar: 22:00\nAbrir: 08:00'
                });

                return true;
            } catch (error) {
                console.error('Erro no comando !fechar:', error);
            }
        }
    } else {
       
        const text = (msg.message.conversation || '').toLowerCase();
        
        if (text.includes('fechar:') && text.includes('abrir:')) {
            try {
                const closeTime = text.match(/fechar:\s*(\d{2}:\d{2})/i)[1];
                const openTime = text.match(/abrir:\s*(\d{2}:\d{2})/i)[1];

                if (!isValidTime(closeTime) || !isValidTime(openTime)) {
                    return sock.sendMessage(jid, {
                        text: '❌ Formato de hora inválido! Use HH:MM (24 horas)'
                    });
                }

                const groupId = Object.entries(groupSchedules).find(
                    ([, schedule]) => schedule.adminId === jid
                )?.[0];

                if (groupId) {
                    setGroupSchedule(groupId, jid, closeTime, openTime);
                    return sock.sendMessage(jid, {
                        text: `✅ Horário atualizado!\nFechar: ${closeTime}\nAbrir: ${openTime}`
                    });
                }

                return sock.sendMessage(jid, {
                    text: '❌ Primeiro envie o comando !fechar no grupo que deseja configurar'
                });

            } catch (error) {
                console.error('Erro ao processar horário:', error);
                sock.sendMessage(jid, {
                    text: '❌ Formato inválido! Use:\nFechar: HH:MM\nAbrir: HH:MM'
                });
            }
        }
    }
    return false;
};

module.exports = {
    loadSchedules,
    startScheduleChecker,
    handleScheduleCommands,
    getGroupSchedule,
    removeGroupSchedule
};