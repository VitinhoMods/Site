const fs = require('fs');
const path = require('path');

const welcomeConfigPath = path.join(__dirname, 'welcomeConfig.json');
let pendingWelcomeRequests = [];

function initWelcomeConfig() {
    if (!fs.existsSync(welcomeConfigPath)) {
        fs.writeFileSync(welcomeConfigPath, JSON.stringify({ groups: {} }, null, 2));
    }
    return JSON.parse(fs.readFileSync(welcomeConfigPath, 'utf8'));
}

function saveWelcomeConfig(config) {
    fs.writeFileSync(welcomeConfigPath, JSON.stringify(config, null, 2));
}

function getWelcomeMessage(groupId) {
    const config = initWelcomeConfig();
    return config.groups[groupId]?.welcomeMessage || 
           "Olá @{nome}, seja bem-vindo(a) ao {grupo}! Por favor leia as regras do grupo.";
}

function setWelcomeMessage(groupId, message) {
    const config = initWelcomeConfig();
    if (!config.groups[groupId]) {
        config.groups[groupId] = { enabled: false };
    }
    config.groups[groupId].welcomeMessage = message;
    saveWelcomeConfig(config);
}

function setWelcomeStatus(groupId, status) {
    const config = initWelcomeConfig();
    if (!config.groups[groupId]) {
        config.groups[groupId] = {
            enabled: status,
            welcomeMessage: getWelcomeMessage(groupId)
        };
    } else {
        config.groups[groupId].enabled = status;
    }
    saveWelcomeConfig(config);
}

function isWelcomeEnabled(groupId) {
    const config = initWelcomeConfig();
    return config.groups[groupId]?.enabled || false;
}

async function getBestAvailableName(sock, participantId) {
    try {
        const [user] = await sock.onWhatsApp(participantId);
        if (user?.exists) {
            return user.pushname || user.verifiedName || participantId.split('@')[0];
        }

        const contact = await sock.getContact(participantId);
        return contact?.pushname || 
               contact?.verifiedName || 
               contact?.name || 
               contact?.notify || 
               participantId.split('@')[0];
    } catch (err) {
        return participantId.split('@')[0];
    }
}

async function handleGroupParticipantJoin(sock, groupEvent) {
    try {
        const { id: groupId, participants, action } = groupEvent;
        
        if (action !== 'add') return;
        if (!isWelcomeEnabled(groupId)) return;
        
        const groupMetadata = await sock.groupMetadata(groupId);
        const groupName = groupMetadata.subject;
        
        for (const participantId of participants) {
            try {
                const userName = await getBestAvailableName(sock, participantId);
                const mentionTag = `@${participantId.split('@')[0]}`;
                
                const welcomeMessage = getWelcomeMessage(groupId)
                    .replace(/{nome}/g, mentionTag)
                    .replace(/{grupo}/g, groupName);

                await sock.sendMessage(
                    groupId, 
                    {
                        text: welcomeMessage,
                        mentions: [participantId]
                    }
                );
            } catch (error) {
                console.error(`Erro nas boas-vindas para ${participantId}:`, error);
            }
        }
    } catch (error) {
        console.error('Erro ao processar entrada no grupo:', error);
    }
}

async function handleWelcomeCommand(sock, msg) {
    const jid = msg.key.remoteJid;
    const sender = msg.key.participant || jid;
    const text = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
    const args = text.split(' ');
    const command = args[1];

    if (!jid.endsWith('@g.us')) {
        await sock.sendMessage(jid, { text: "Este comando só funciona em grupos." });
        return;
    }

    const groupMetadata = await sock.groupMetadata(jid);
    const isAdmin = groupMetadata.participants
        .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
        .some(p => p.id === sender);

    if (!isAdmin) {
        await sock.sendMessage(jid, { text: "Apenas administradores podem configurar as boas-vindas." });
        return;
    }

    if (command === 'on') {
        setWelcomeStatus(jid, true);
        await sock.sendMessage(jid, { text: '✅ Mensagens de boas-vindas ativadas' });
    } 
    else if (command === 'off') {
        setWelcomeStatus(jid, false);
        await sock.sendMessage(jid, { text: '❌ Mensagens de boas-vindas desativadas' });
    }
    else if (command === 'set') {
        await requestWelcomeMessage(sock, sender, jid, groupMetadata.subject);
    }
    else {
        const status = isWelcomeEnabled(jid) ? '✅ ATIVADO' : '❌ DESATIVADO';
        await sock.sendMessage(jid, {
            text: `Configuração de boas-vindas (${status})\n\n` +
                  'Comandos disponíveis:\n' +
                  '!welcome on - Ativa as boas-vindas\n' +
                  '!welcome off - Desativa as boas-vindas\n' +
                  '!welcome set - Define mensagem personalizada\n\n' +
                  'Mensagem atual:\n' + getWelcomeMessage(jid)
        });
    }
}

async function requestWelcomeMessage(sock, userJid, groupJid, groupName) {
    await sock.sendMessage(
        userJid, 
        { 
            text: `📝 Configurar mensagem de boas-vindas para "${groupName}"\n\n` +
                  'Envie a mensagem que deseja usar. Você pode usar:\n' +
                  '{nome} - Menciona o novo membro com @\n' +
                  '{grupo} - Nome do grupo\n\n' +
                  'Exemplo: "Olá @{nome}, bem-vindo(a) ao {grupo}!"'
        }
    );
    
    
    pendingWelcomeRequests.push({
        userJid,
        groupJid,
        timestamp: Date.now()
    });
}

async function handleWelcomeMessageResponse(sock, msg, pendingRequests) {
    const jid = msg.key.remoteJid;
    const text = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
    
    
    const requestIndex = pendingRequests.findIndex(req => req.userJid === jid);
    if (requestIndex === -1) return false;
    
    const { groupJid } = pendingRequests[requestIndex];
    
    
    pendingRequests.splice(requestIndex, 1);
    
    
    setWelcomeMessage(groupJid, text);
    
    await sock.sendMessage(jid, { 
        text: `✅ Mensagem de boas-vindas atualizada para o grupo!`
    });
    
    await sock.sendMessage(groupJid, {
        text: `A mensagem de boas-vindas foi atualizada por um administrador.`
    });
    
    return true;
}

module.exports = {
    handleGroupParticipantJoin,
    handleWelcomeCommand,
    initWelcomeConfig,
    handleWelcomeMessageResponse,
    pendingWelcomeRequests
};