const path = require('path');
const fs = require('fs');
const MODS_FILE = path.resolve(__dirname, 'modsList.json');
const AUTHORIZED_NUMBERS = [
    '5514998886728@s.whatsapp.net',
    '558581870145@s.whatsapp.net'

];

const YOUTUBE_CHANNELS = {
    main: "https://youtube.com/",
    tutorials: "https://youtube.com/"
};
let modsData = {
    groups: {},
    lastIndex: 0,
    rateLimits: {}
};
const loadModsData = () => {
    try {
        if (fs.existsSync(MODS_FILE)) {
            const data = fs.readFileSync(MODS_FILE, 'utf8');
            modsData = JSON.parse(data);
            if (!modsData.rateLimits) modsData.rateLimits = {};
        }
    } catch (error) {
        console.error('Erro ao carregar mods:', error);
        saveModsData();
    }
};
const saveModsData = () => {
    try {
        fs.writeFileSync(MODS_FILE, JSON.stringify(modsData, null, 2));
    } catch (error) {
        console.error('Erro ao salvar mods:', error);
    }
};
const addMod = (groupId, modInfo) => {
    if (!modsData.groups[groupId]) {
        modsData.groups[groupId] = { mods: [] };
    }
    
    const newMod = {
        id: ++modsData.lastIndex,
        ...modInfo,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    };
    
    modsData.groups[groupId].mods.push(newMod);
    saveModsData();
    return newMod;
};
const getGroupMods = (groupId, listType = 1) => {
    return modsData.groups[groupId]?.mods.filter(m => m.listType === listType) || [];
};


const getAllGroupMods = (groupId) => {
    if (!modsData.groups[groupId]) return [];
    
    
    return modsData.groups[groupId].mods.sort((a, b) => a.id - b.id);
};

const isAuthorized = (jid) => {
    return AUTHORIZED_NUMBERS.includes(jid);
};
const checkRateLimit = (jid) => {
    const now = Date.now();
    const user = jid.split('@')[0];
    const MAX_ATTEMPTS = 5; 
    const COOLDOWN_TIME = 300000; 

    
    if (modsData.rateLimits[user]) {
        
        if (modsData.rateLimits[user].cooldownUntil && now < modsData.rateLimits[user].cooldownUntil) {
            return true; 
        }
        
       
        if (modsData.rateLimits[user].cooldownUntil && now >= modsData.rateLimits[user].cooldownUntil) {
            modsData.rateLimits[user] = { 
                lastRequest: now, 
                attempts: 1,
                cooldownUntil: null 
            };
            saveModsData();
            return false;
        }

        
        if (modsData.rateLimits[user].attempts >= MAX_ATTEMPTS) {
            
            modsData.rateLimits[user].cooldownUntil = now + COOLDOWN_TIME;
            saveModsData();
            return true;
        }

        
        modsData.rateLimits[user].attempts++;
        modsData.rateLimits[user].lastRequest = now;
        saveModsData();
        return false;
    }
    
    
    modsData.rateLimits[user] = { 
        lastRequest: now, 
        attempts: 1,
        cooldownUntil: null 
    };
    saveModsData();
    return false;
};

const getRateLimitMessage = (jid) => {
    const attempts = modsData.rateLimits[jid.split('@')[0]]?.attempts || 1;
    return attempts > 3 
        ? '🛑 Você já pediu muitas vezes! Espere 5 minutos.'
        : '⏳ Aguarde 5 minutos para ver a lista novamente.';
};


const parseDeltaMod = (modText) => {
    
    let cleanText = modText.replace(/^!addmod\s+/i, '').trim();
    
    
    const firstSplit = cleanText.split('|');
    if (firstSplit.length < 2) {
        throw new Error('Formato inválido: Faltam delimitadores |');
    }
    
    const name = firstSplit[0].trim();
    const version = firstSplit[1].trim();
    
    
    const contentText = cleanText.substring(name.length + version.length + 3).trim();
    
    
    let description = '';
    let linksAndExtras = contentText;
    
    const firstNumberedItemMatch = contentText.match(/[1-4]️⃣/);
    if (firstNumberedItemMatch) {
        const index = contentText.indexOf(firstNumberedItemMatch[0]);
        description = contentText.substring(0, index).trim();
        linksAndExtras = contentText.substring(index).trim();
    }
    
    
    const deltaLinks = [];
    const linkRegex = /([1-4]️⃣.*?)(?=[1-4]️⃣|🔰|®️|$)/gs;
    let linkMatch;
    
    while ((linkMatch = linkRegex.exec(linksAndExtras)) !== null) {
        const linkText = linkMatch[1].trim();
        
        
        const numberMatch = linkText.match(/([1-4]️⃣)/);
        const number = numberMatch ? numberMatch[0] : '';
        
        
        const firstLineIndex = linkText.indexOf('\n');
        const titleLine = firstLineIndex !== -1 ? 
            linkText.substring(number.length, firstLineIndex).trim() : 
            linkText.substring(number.length).trim();
        
        
        const linkLineMatch = linkText.match(/[\s\n](-https?:\/\/[^\s\n]+|https?:\/\/[^\s\n]+)/);
        const link = linkLineMatch ? linkLineMatch[1].replace(/^-/, '') : '';
        
        
        let package = '';
        if (firstLineIndex !== -1) {
            const lines = linkText.split('\n');
            for (let i = 1; i < lines.length; i++) {
                if (lines[i].trim() && !lines[i].includes('http') && !lines[i].startsWith('-')) {
                    package = lines[i].trim();
                    break;
                }
            }
        }
        
        deltaLinks.push({
            number,
            title: titleLine,
            package,
            link
        });
    }
    
    
    const extras = {};
    
    
    const extrasText = linksAndExtras.replace(/[1-4]️⃣.*?(?=[1-4]️⃣|🔰|®️|$)/gs, '').trim();
    
    if (extrasText) {
        const extraLines = extrasText.split('\n');
        for (let i = 0; i < extraLines.length; i++) {
            const line = extraLines[i].trim();
            if (line) {
                const symbol = line.match(/^[🔰®️]/);
                if (symbol) {
                    const key = symbol[0];
                    const value = line.substring(1).trim();
                    extras[key] = value;
                } else if (i === extraLines.length - 1) {
                    
                    extras['📝'] = line;
                }
            }
        }
    }
    
    return {
        name,
        version,
        description,
        deltaLinks,
        extras,
        listType: 2
    };
};


loadModsData();
module.exports = {
    loadModsData,
    addMod,
    getGroupMods,
    getAllGroupMods,
    isAuthorized,
    checkRateLimit,
    getRateLimitMessage,
    YOUTUBE_CHANNELS,
    parseDeltaMod
};