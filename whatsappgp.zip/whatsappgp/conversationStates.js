class ConversationState {
    constructor() {
        this.states = new Map();
        this.timeouts = new Map();
    }

    setState(userJid, state, data = {}, timeout = 300000) { 
        this.clearState(userJid); 
        
        this.states.set(userJid, { state, data });
        
        const timeoutId = setTimeout(() => {
            this.states.delete(userJid);
            this.timeouts.delete(userJid);
        }, timeout);
        
        this.timeouts.set(userJid, timeoutId);
    }

    getState(userJid) {
        return this.states.get(userJid);
    }

    clearState(userJid) {
        this.states.delete(userJid);
        if (this.timeouts.has(userJid)) {
            clearTimeout(this.timeouts.get(userJid));
            this.timeouts.delete(userJid);
        }
    }
}

module.exports = new ConversationState();