const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
  sendDeveloperInfo: async (sock, jid) => {
    const developerInfo = `
🌟 *Informações do Desenvolvedor* 🌟

🤖 *Sobre o Bot:*
Este é um bot multifuncional para WhatsApp desenvolvido em Node.js usando a biblioteca Baileys. Desenvolvido para ajudar na moderação de grupos e fornecer diversos recursos úteis para a comunidade.

👨💻 *Sobre Mim:*
Sou um desenvolvedor apaixonado por criar soluções inovadoras. Atuo principalmente com JavaScript/Node.js/python e desenvolvimento de bots.

📌 *Redes Sociais:*
- GitHub: https://github.com/VitinhoMods
- Telegram: https://t.me/modder4_apps
- Instagram: @Vitinho_Mods

🔧 *Canal de Atualizações:*
Acompanhe as novidades do bot em nosso canal do Telegram:
https://t.me/modder4_apps

💡 *Dúvidas ou Sugestões?*
Entre em contato via DM ou abra uma issue no GitHub!
    `.trim();

    try {
      const response = await axios.get('https://i.imgur.com/xxx.jpg', {
        responseType: 'arraybuffer'
      });
      const thumbnailBuffer = Buffer.from(response.data);

      await sock.sendMessage(jid, {
        text: developerInfo,
        contextInfo: {
          mentionedJid: [jid],
          externalAdReply: {
            title: "Desenvolvedor do Bot",
            body: "Clique para ver mais informações",
            thumbnail: thumbnailBuffer,
            mediaType: 1,
            mediaUrl: 'https://github.com/VitinhoMods',
            sourceUrl: 'https://github.com/VitinhoMods'
          }
        }
      });
    } catch (error) {
      console.error("Erro ao enviar informações do desenvolvedor:", error);
      throw error;
    }
  }
};