const path = require("path");
const fs = require('fs');
const {
    default: makeWASocket,
    DisconnectReason,
    useMultiFileAuthState,
    fetchLatestBaileysVersion,
    downloadMediaMessage,
} = require("@whiskeysockets/baileys");
const readline = require("readline");
const pino = require("pino");
const groupManagement = require("./groupManagement");
const { getMenuMessage } = require("./menu");
const { handleStickerCommands } = require("./sticker");
const { chiparCasal } = require("./chiparCasal");
const { sendDeveloperInfo } = require("./commands/developerInfo");
const { spawn } = require("child_process");
const cron = require('node-cron');
const { handleModsCommands } = require('./modsHandlers');
const { loadModsData } = require('./modsManager');
const { 
    loadAllowedLinks,
    addAllowedChannel,
    removeAllowedChannel,
    getAllowedChannels
} = require('./allowedLinks');


const {
    handleGroupParticipantJoin,
    handleWelcomeCommand,
    handleWelcomeMessageResponse,
    initWelcomeConfig
} = require("./welcomeManager");


const {
    handleRulesCommand,
    handleRulesMessageResponse,
    getRulesForGroup,
    pendingRulesRequests,
} = require("./rulesManager");


const SCHEDULE_FILE = path.resolve(__dirname, 'groupSchedules.json');
let groupSchedules = {};


const loadSchedules = () => {
    try {
        if (fs.existsSync(SCHEDULE_FILE)) {
            const data = fs.readFileSync(SCHEDULE_FILE, 'utf8');
            groupSchedules = JSON.parse(data);
        }
    } catch (error) {
        console.error('Erro ao carregar agendamentos:', error);
    }
};


const saveSchedules = () => {
    try {
        fs.writeFileSync(SCHEDULE_FILE, JSON.stringify(groupSchedules, null, 2));
    } catch (error) {
        console.error('Erro ao salvar agendamentos:', error);
    }
};


const isValidTime = (time) => {
    return /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(time);
};


const timeToMinutes = (time) => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
};


const setGroupSchedule = (groupId, adminId, closeTime, openTime) => {
    groupSchedules[groupId] = {
        adminId,
        closeTime,
        openTime,
        isClosed: false
    };
    saveSchedules();
};


const handleScheduleCommands = async (sock, msg) => {
    const jid = msg.key.remoteJid;
    const isGroup = jid.endsWith('@g.us');
    const sender = msg.key.participant || jid;

    if (isGroup) {
        const text = (msg.message.conversation || '').toLowerCase();
        
        if (text.startsWith('!fechar')) {
            try {
                const metadata = await sock.groupMetadata(jid);
                const isAdmin = metadata.participants.find(p => p.id === sender)?.admin;
                
                if (!isAdmin) {
                    await sock.sendMessage(jid, {
                        text: '⚠️ Apenas administradores podem configurar o horário!',
                        mentions: [sender]
                    });
                    return true;
                }

                await sock.sendMessage(sender, {
                    text: '⏰ *Configurar Horário do Grupo*\n\nEnvie o horário no formato:\n`Fechar: HH:MM\nAbrir: HH:MM`\n\nExemplo:\nFechar: 22:00\nAbrir: 08:00'
                });

                return true;
            } catch (error) {
                console.error('Erro no comando !fechar:', error);
            }
        }
    } else {
        const text = (msg.message.conversation || '').toLowerCase();
        
        if (text.includes('fechar:') && text.includes('abrir:')) {
            try {
                const closeTime = text.match(/fechar:\s*(\d{2}:\d{2})/i)[1];
                const openTime = text.match(/abrir:\s*(\d{2}:\d{2})/i)[1];

                if (!isValidTime(closeTime) || !isValidTime(openTime)) {
                    await sock.sendMessage(jid, {
                        text: '❌ Formato de hora inválido! Use HH:MM (24 horas)'
                    });
                    return true;
                }

                const groupId = Object.entries(groupSchedules).find(
                    ([, schedule]) => schedule.adminId === jid
                )?.[0];

                if (groupId) {
                    setGroupSchedule(groupId, jid, closeTime, openTime);
                    await sock.sendMessage(jid, {
                        text: `✅ Horário atualizado!\nFechar: ${closeTime}\nAbrir: ${openTime}`
                    });
                    await sock.sendMessage(groupId, {
                        text: `⏰ Horário do grupo configurado!\nO grupo será fechado às ${closeTime} e reaberto às ${openTime}`
                    });
                    return true;
                }

                await sock.sendMessage(jid, {
                    text: '❌ Primeiro envie o comando !fechar no grupo que deseja configurar'
                });
                return true;

            } catch (error) {
                console.error('Erro ao processar horário:', error);
                await sock.sendMessage(jid, {
                    text: '❌ Formato inválido! Use:\nFechar: HH:MM\nAbrir: HH:MM'
                });
                return true;
            }
        }
    }
    return false;
};


const startScheduleChecker = (sock) => {
    cron.schedule('* * * * *', async () => {
        const now = new Date();
        const currentMinutes = now.getHours() * 60 + now.getMinutes();

        for (const [groupId, schedule] of Object.entries(groupSchedules)) {
            const closeMinutes = timeToMinutes(schedule.closeTime);
            const openMinutes = timeToMinutes(schedule.openTime);

            try {
                const metadata = await sock.groupMetadata(groupId);
                const isAdmin = metadata.participants.some(p => p.id === sock.user.id && p.admin);

                if (!isAdmin) {
                    delete groupSchedules[groupId];
                    saveSchedules();
                    continue;
                }

                if (!schedule.isClosed && currentMinutes >= closeMinutes) {
                    await sock.groupSettingUpdate(groupId, 'announcement');
                    schedule.isClosed = true;
                    await sock.sendMessage(groupId, {
                        text: `🚪 O grupo foi fechado!\nHorário de funcionamento: ${schedule.openTime} às ${schedule.closeTime}\n\nApenas administradores podem enviar mensagens.`
                    });
                } else if (schedule.isClosed && currentMinutes >= openMinutes) {
                    await sock.groupSettingUpdate(groupId, 'not_announcement');
                    schedule.isClosed = false;
                    await sock.sendMessage(groupId, {
                        text: `🚪 O grupo foi reaberto!\nNovo horário de fechamento: ${schedule.closeTime}\n\nTodos os membros podem enviar mensagens novamente!`
                    });
                }
            } catch (error) {
                console.error(`Erro ao atualizar grupo ${groupId}:`, error);
                if (error.output?.statusCode === 403) {
                    delete groupSchedules[groupId];
                    saveSchedules();
                }
            }
        }
        saveSchedules();
    });
};


const question = (string) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise((resolve) => rl.question(string, resolve));
};


const pendingWelcomeRequests = [];


async function handleStickerSenderCommands(sock, msg) {
    const text = msg.message.conversation || msg.message.extendedTextMessage?.text || "";

    if (!text.startsWith("!figurinhas")) return false;

    const partes = text.split(" ");
    if (partes.length < 2) {
        await sock.sendMessage(msg.key.remoteJid, {
            text: "Por favor, informe a quantidade de figurinhas a enviar. Ex: !figurinhas 5"
        });
        return true;
    }

    const quantidade = parseInt(partes[1], 10);
    if (isNaN(quantidade)) {
        await sock.sendMessage(msg.key.remoteJid, {
            text: "Quantidade inválida. Por favor, informe um número."
        });
        return true;
    }

    if (quantidade > 10) {
        await sock.sendMessage(msg.key.remoteJid, {
            text: "Haha, não posso enviar mais de 10 figurinhas de uma vez! Tente um número menor ou igual a 10."
        });
        return true;
    }

    if (quantidade < 1) {
        await sock.sendMessage(msg.key.remoteJid, {
            text: "A quantidade deve ser no mínimo 1 figurinha."
        });
        return true;
    }

    const stickersDir = path.resolve(__dirname, "stickers");
    if (!fs.existsSync(stickersDir)) {
        await sock.sendMessage(msg.key.remoteJid, {
            text: "Diretório de figurinhas não encontrado."
        });
        return true;
    }

    const stickerFiles = fs.readdirSync(stickersDir).filter(file => file.endsWith('.webp'));
    if (stickerFiles.length === 0) {
        await sock.sendMessage(msg.key.remoteJid, {
            text: "Nenhuma figurinha encontrada no diretório."
        });
        return true;
    }

    for (let i = 0; i < quantidade; i++) {
        const randomSticker = stickerFiles[Math.floor(Math.random() * stickerFiles.length)];
        const stickerPath = path.resolve(stickersDir, randomSticker);
        await sock.sendMessage(msg.key.remoteJid, { sticker: { url: stickerPath } });
    }

    return true;
}

async function connect() {
    const { state, saveCreds } = await useMultiFileAuthState(
        path.resolve(__dirname, "auth")
    );

    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        printQRInTerminal: false,
        version,
        logger: pino({ level: "silent" }),
        auth: state,
        browser: ["Ubuntu", "Chrome", "1.0.0"],
        markOnlineOnConnect: true,
    });

    
    loadModsData();
    loadAllowedLinks();
    loadSchedules();
    initWelcomeConfig();
    startScheduleChecker(sock);

    if (!sock.authState.creds.registered) {
        let phoneNumber = await question("Informe o número com código do país (ex: 5511999999999): ");
        phoneNumber = phoneNumber.replace(/[^0-9]/g, "");

        if (!phoneNumber) throw new Error("Número inválido!");

        const code = await sock.requestPairingCode(phoneNumber);
        console.log(`\nCódigo de pareamento: ${code}\n`);
    }

    sock.ev.on("connection.update", (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === "close") {
            const shouldReconnect =
                lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log("Conexão fechada. Reconectando...");
            if (shouldReconnect) connect();
        } else if (connection === "open") {
            console.log("✅ Conectado com sucesso!");

            const messages = [
                "Lembrem-se das regras do grupo!",
                "Participem ativamente!",
                "Respeitem todos os membros!"
            ];
            groupManagement.randomMessages(sock, "seu-grupo-id@grupos.whatsapp.net", messages, 60);
        }
    });

    sock.ev.on("creds.update", saveCreds);

    async function downloadAndSendMusic(jid, query) {
        const fileName = `music_${Date.now()}.mp3`;
        const outputPath = path.resolve(__dirname, fileName);

        const ytDlp = spawn("yt-dlp", [
            "-x",
            "--audio-format", "mp3",
            "--audio-quality", "0",
            "--no-playlist",
            "--no-check-certificate",
            "--ignore-errors",
            "-o", outputPath,
            `ytsearch1:"${query}"`
        ]);

        let stderr = '';
        ytDlp.stderr.on('data', (data) => {
            stderr += data.toString();
            console.error('[yt-dlp ERROR]:', data.toString());
        });

        ytDlp.on('error', async (err) => {
            console.error('Erro no processo yt-dlp:', err);
            await sock.sendMessage(jid, { 
                text: `❌ Falha ao iniciar o download: ${err.message}`
            });
        });

        ytDlp.on('close', async (code) => {
            if (code === 0) {
                if (fs.existsSync(outputPath)) {
                    try {
                        await sock.sendMessage(jid, {
                            audio: fs.readFileSync(outputPath),
                            mimetype: "audio/mpeg",
                            fileName: `${query.replace(/[^a-z0-9]/gi, '_')}.mp3`
                        });
                    } catch (sendError) {
                        console.error('Erro ao enviar:', sendError);
                        await sock.sendMessage(jid, { 
                            text: "❌ Erro ao enviar o arquivo baixado"
                        });
                    } finally {
                        if (fs.existsSync(outputPath)) {
                            fs.unlinkSync(outputPath);
                        }
                    }
                } else {
                    await sock.sendMessage(jid, { 
                        text: "❌ O arquivo foi baixado mas não foi encontrado"
                    });
                }
            } else {
                await sock.sendMessage(jid, { 
                    text: `❌ Falha no download: ${stderr.slice(0, 200)}...`
                });
            }
        });
    }

    sock.ev.on("group-participants.update", async (groupEvent) => {
        await handleGroupParticipantJoin(sock, groupEvent);
    });

    sock.ev.on("messages.upsert", async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message) return;

        const jid = msg.key.remoteJid;
        const isGroup = jid.endsWith("@g.us");
        const sender = msg.key.participant || jid;

        
        const handledMods = await handleModsCommands(sock, msg);
        if (handledMods) return;

        
        const handledSchedule = await handleScheduleCommands(sock, msg);
        if (handledSchedule) return;

        if (isGroup && msg.message.stickerMessage) {
            try {
                const stickersDir = path.resolve(__dirname, "stickers");
                if (!fs.existsSync(stickersDir)) {
                    fs.mkdirSync(stickersDir, { recursive: true });
                }

                const timestamp = Date.now();
                const randomNum = Math.floor(Math.random() * 10000);
                const stickerName = `STK-${timestamp}-${randomNum}.webp`;
                const stickerPath = path.resolve(stickersDir, stickerName);

                const buffer = await downloadMediaMessage(msg, "buffer", {});
                fs.writeFileSync(stickerPath, buffer);
            } catch (error) {
                console.error("Erro ao salvar figurinha:", error);
            }
        }

        if (msg.key.fromMe) return;

        const text = msg.message.conversation?.toLowerCase() ||
                     msg.message.extendedTextMessage?.text?.toLowerCase() ||
                     "";

        if (text.startsWith("!play ")) {
            const query = text.replace("!play ", "").trim();
            if (!query) return await sock.sendMessage(jid, { text: "❌ Informe o nome da música!" });

            await sock.sendMessage(jid, { text: `🎵 Baixando "${query}", aguarde😎...` });
            downloadAndSendMusic(jid, query);
            return;
        }

        if (!isGroup) {
            const processedRules = await handleRulesMessageResponse(sock, msg);
            if (processedRules) return;

            const processedWelcome = await handleWelcomeMessageResponse(sock, msg, pendingWelcomeRequests);
            if (processedWelcome) return;
        }

        if (isGroup) {
            try {
                const antiLinkResult = await groupManagement.antiLink(sock, msg);
                if (antiLinkResult?.actionTaken) return;
            } catch (error) {
                console.error("Erro no anti-link:", error);
            }
        }

        if (isGroup) {
            const spamResult = await groupManagement.antiSpam(sock, msg);
            if (spamResult.action === "banned") return;
        }

        
        if (text.startsWith("!antispam")) {
            const metadata = await sock.groupMetadata(jid);
            const isAdmin = metadata.participants.find(p => p.id === sender)?.admin;

            if (!isAdmin) {
                await sock.sendMessage(jid, { 
                    text: "❌ Este comando é restrito a administradores!",
                    mentions: [sender]
                });
                return;
            }

            const [cmd, action] = text.toLowerCase().split(' ');

            if (!action) {
                const currentStatus = groupManagement.getAntiSpamConfig(jid).enabled ? 'ATIVADO' : 'DESATIVADO';
                await sock.sendMessage(jid, {
                    text: `⚙️ *Configuração do Anti-Spam*\n\nUso: !antispam [on|off]\nStatus atual: ${currentStatus}`
                });
                return;
            }

            if (action === 'on' || action === 'off') {
                groupManagement.setAntiSpamConfig(jid, action === 'on');

                const statusMsg = action === 'on' 
                    ? "✅ *Sistema Anti-Spam Ativado*\n\nO sistema agora está monitorando e protegendo o grupo contra mensagens repetitivas e spam excessivo."
                    : "❌ *Sistema Anti-Spam Desativado*\n\nAtenção: O grupo está temporariamente sem proteção contra spam!\n_\"Quando o gato sai, os ratos fazem a festa! 🐭🎉\"_";

                await sock.sendMessage(jid, {
                    text: statusMsg,
                    mentions: [sender]
                });
            } else {
                await sock.sendMessage(jid, {
                    text: "❌ Comando inválido! Use: !antispam on ou !antispam off"
                });
            }
            return;
        }

        
        if (text.startsWith('!allowlink')) {
            const metadata = await sock.groupMetadata(jid);
            const isAdmin = metadata.participants.find(p => p.id === sender)?.admin;

            if (!isAdmin) {
                await sock.sendMessage(jid, {
                    text: '⚠️ Apenas administradores podem gerenciar links permitidos!',
                    mentions: [sender]
                });
                return;
            }

            const [command, action, ...channelParts] = text.split(' ');
            const channel = channelParts.join(' ');

            if (!action || !['add', 'remove'].includes(action.toLowerCase())) {
                const currentChannels = getAllowedChannels(jid).join('\n') || 'Nenhum canal permitido';
                await sock.sendMessage(jid, {
                    text: `📝 *Gerenciar Links Permitidos*\n\nUso:\n!allowlink add [canal]\n!allowlink remove [canal]\n\nCanais permitidos:\n${currentChannels}`
                });
                return;
            }

            if (action === 'add') {
                addAllowedChannel(jid, channel);
                await sock.sendMessage(jid, {
                    text: `✅ Canal permitido adicionado:\n${channel}`
                });
            } else if (action === 'remove') {
                removeAllowedChannel(jid, channel);
                await sock.sendMessage(jid, {
                    text: `❌ Canal permitido removido:\n${channel}`
                });
            }
            return;
        }

        const stickerCommands = ['!sticker', '!s', '!sticker', '!stext', '!st', '!stickertext', '!shelp', '!stickerhelp', '!shelp'];
        if (stickerCommands.some(cmd => text.startsWith(cmd))) {
            await handleStickerCommands(sock, msg);
            return;
        }

        if (isGroup) {
            
            if (text === "!welcome" || text.startsWith("!welcome ")) {
                await handleWelcomeCommand(sock, msg);
                return;
            }

            if (text === "!editrules") {
                await handleRulesCommand(sock, msg);
                return;
            }

            if (text === "!regras" || text === "!getrules") {
                const rules = getRulesForGroup(jid);
                await sock.sendMessage(jid, { text: `Regras do grupo:\n\n${rules}` });
                return;
            }

            if (text.startsWith("!ban ")) {
                const userId = text.split(" ")[1];
                if (!userId) {
                    await sock.sendMessage(jid, { text: "Por favor, informe o número do usuário. Ex: /ban 5511999999999" });
                    return;
                }
                const formattedUserId = userId.replace(/\D/g, "") + "@s.whatsapp.net";
                const result = await groupManagement.banUser(sock, jid, [formattedUserId]);
                await sock.sendMessage(jid, { text: result.error || "Usuário banido com sucesso" });
            }

            if (text.startsWith("!marcar")) {
                const users = text.split(" ").slice(1);
                if (users.length === 0) {
                    await sock.sendMessage(jid, { text: "Por favor, informe os números dos usuários. Ex: /marcar 5511999999999 5511888888888" });
                    return;
                }
                const result = await groupManagement.mentionUsers(sock, jid, users, "Marcando usuários:");
                if (result.error) await sock.sendMessage(jid, { text: result.error });
            }

            if (text.startsWith("!figurinhas")) {
                let handled = await handleStickerSenderCommands(sock, msg);
                if (handled) return;
            }

            if (text === "!limpar") {
                await sock.sendMessage(jid, { text: "Tem certeza que deseja limpar o chat? (sim/não)" });
                const confirmation = await new Promise((resolve) => {
                    sock.ev.once("messages.upsert", ({ messages }) => {
                        const response = messages[0].message.conversation?.toLowerCase();
                        resolve(response === "sim");
                    });
                });
                if (confirmation) {
                    const result = await groupManagement.clearChat(sock, jid);
                    await sock.sendMessage(jid, { text: result.error || "Chat limpo com sucesso" });
                } else {
                    await sock.sendMessage(jid, { text: "Operação cancelada." });
                }
            }
        }

        if (text === "!chipar") {
            try {
                const groupMetadata = await sock.groupMetadata(jid);
                const participants = groupMetadata.participants.map(p => p.id);
                const mensagemCasal = chiparCasal(participants);
                await sock.sendMessage(jid, { text: mensagemCasal });
            } catch (error) {
                console.error("Erro ao chipar casal:", error);
                await sock.sendMessage(jid, { text: "Erro ao tentar chipar casal. Tente novamente." });
            }
            return;
        }

        if (text === '!dev' || text === '!sobre' || text === '!developer') {
            await sendDeveloperInfo(sock, jid);
            return;
        }

        if (text === "!menu" || text === "!help" || text === "!comandos") {
            const imagePath = path.resolve(__dirname, 'fotos', 'menu.jpg');

            if (fs.existsSync(imagePath)) {
                await sock.sendMessage(jid, {
                    image: { url: imagePath },
                    caption: getMenuMessage(),
                    mentions: [msg.key.participant || msg.key.remoteJid]
                });
            } else {
                await sock.sendMessage(jid, {
                    text: getMenuMessage(),
                    mentions: [msg.key.participant || msg.key.remoteJid]
                });
            }
        }

        if (text === "!ping") {
            await sock.sendMessage(jid, { text: "🏓 Pong!" });
        }

        const now = Date.now();
        const timeoutMs = 10 * 60 * 1000;
        const expiredRequestsIndex = pendingWelcomeRequests.findIndex(req => now - req.timestamp > timeoutMs);
        if (expiredRequestsIndex !== -1) {
            pendingWelcomeRequests.splice(0, expiredRequestsIndex + 1);
        }
    });

    return sock;
}

connect()
    .then(() => console.log("Bot pronto para uso!"))
    .catch((err) => console.error("Erro na conexão:", err));
    
    
    
