module.exports.getMenuMessage = () => {
  return `
🎇 *MENU DE COMANDOS* 🎇

📚 *Catálogo de Funcionalidades:*

🛠️  *COMANDOS BÁSICOS*
├─ 🏓 !ping - Testa a latência do bot
├─ ℹ️ !info - Exibe informações técnicas
├─ 🎩 !dev - Mostra dados do desenvolvedor
└─ 📖 !menu - Exibe este menu interativo

🖼️  *FIGURINHAS*
├─ ⭐ !sticker - Converte imagens/vídeos em figurinha
├─ ✨ !stext - Cria figurinha com texto personalizado
└─ 🎰 !figurinhas [1-10] - Envia X figurinhas aleatórias (máx. 10)

🛡️  *ADMINISTRAÇÃO*
├─ ⚠️ !ban [@] - Remove usuário do grupo
├─ 📢 !marcar [@] - Menciona múltiplos usuários
├─ 📜 !regras - Exibe as regras do grupo
├─ 🎉 !welcome [on/off/set] - Configura mensagem de boas-vindas
├─ ⏰ !fechar - Agenda horário de funcionamento
├─ 🚫 !antispam [on/off] - Controle de flood (Beta)
└─ 🔗 !allowlink [add/rem] - Gerencia links permitidos

🎵  *MÚSICA*
└─ 🎧 !play [nome] - Baixa e envia músicas do YouTube (Ainda não funciona)

⚙️  *CONFIGURAÇÕES*
├─ 🧹 !limpar - Apaga todas as mensagens (ADM)
└─ 🤖 !addpv - Inicia configuração de novos MODs

🎮  *DIVERSÃO*
└─ 💘 !chipar - Sorteia casais aleatórios (Temporariamente off)

📦  *MODs*
├─ 📥 mods - Lista todos os MODs disponíveis
├─ 🔄 !updatemod [ID] [version/link] [valor] - Atualiza MOD
└─ 🗑️ !removemod [ID] - Remove MOD específico

🔰 *Notas:*
- (Beta) = Funcionalidade em testes
- Comandos com [ ] exigem parâmetros
- Prefixo "!" para todos os comandos
- Use !welcome set para personalizar a mensagem de boas-vindas

📡 *Desenvolvido por OnwDev* 🔥
*wa.me/5585981590728* 👨💻
`;
};