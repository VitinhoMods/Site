const { 
    addMod,
    getGroupMods,
    getAllGroupMods,
    isAuthorized,
    checkRateLimit,
    getRateLimitMessage,
    YOUTUBE_CHANNELS,
    parseDeltaMod
} = require('./modsManager');
const conversationState = require('./conversationStates');

const handleModsCommands = async (sock, msg) => {
    if (!msg.message || msg.key.fromMe) return false;
    
    const jid = msg.key.remoteJid;
    const isGroup = jid.endsWith('@g.us');
    const sender = msg.key.participant || jid;
    const text = (msg.message.conversation || '').trim();

    
    if (!isGroup) {
        return await handlePrivateModConversation(sock, msg, jid, text);
    }

    
    const state = conversationState.getState(jid);
    if (state && state.state === 'AWAITING_MOD_SELECTION') {
        try {
            const number = parseInt(text, 10);
            if (isNaN(number)) {
                await sock.sendMessage(jid, { text: '❌ Por favor, envie um número válido da lista.' });
                return true;
            }

            const modsList = state.data.modsList;
            if (number < 1 || number > modsList.length) {
                await sock.sendMessage(jid, { text: '❌ Número inválido. Escolha um número da lista.' });
                return true;
            }

            const selectedMod = modsList[number - 1];
            const formattedDate = new Date(selectedMod.updated).toLocaleDateString('pt-BR', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });

            
            const listType = selectedMod.listType || 1;
            
            let responseMessage = '';
            if (listType === 2) {
                
                responseMessage = `🤖 *${selectedMod.name} ${selectedMod.version}*\n\n` +
                      `${selectedMod.description ? selectedMod.description + '\n\n' : ''}`;
                
                
                if (selectedMod.deltaLinks && selectedMod.deltaLinks.length > 0) {
                    selectedMod.deltaLinks.forEach(linkItem => {
                        responseMessage += `${linkItem.number} ${linkItem.title}\n`;
                        if (linkItem.package) responseMessage += `${linkItem.package}\n`;
                        responseMessage += `${linkItem.link}\n\n`;
                    });
                } else if (selectedMod.link) {
                    
                    responseMessage += `🔗 ${selectedMod.link}\n\n`;
                }
                
                
                if (selectedMod.extras) {
                    Object.keys(selectedMod.extras).forEach(key => {
                        responseMessage += `${key} ${selectedMod.extras[key]}\n`;
                    });
                    responseMessage += '\n';
                }
                
                responseMessage += `📆 Atualizado em: ${formattedDate}`;
            } else {
                
                responseMessage = `🤖 *Aqui está seu MOD fresquinho!*\n\n` +
                      `👉 ${selectedMod.name} ${selectedMod.version}\n` +
                      `🔗 ${selectedMod.link}\n\n` +
                      `📺 *Vídeos novos toda semana:*\n` +
                      `😎 Canal Principal ➜ ${YOUTUBE_CHANNELS.main}\n` +
                      `🛠️ Tutoriais ➜ ${YOUTUBE_CHANNELS.tutorials}\n\n` +
                      `📆 Atualizado em: ${formattedDate}\n\n` +
                      `💬 "Like" nos vídeos pra me ajudar! ❤️`;
            }

            await sock.sendMessage(jid, { text: responseMessage });

            conversationState.clearState(jid);
            return true;
        } catch (error) {
            console.error('Erro ao processar seleção:', error);
            conversationState.clearState(jid);
            await sock.sendMessage(jid, { text: '❌ Ocorreu um erro!' });
            return true;
        }
    }

  
    if (text.toLowerCase() === 'mods') {
        try {
            if (checkRateLimit(sender)) {
                await sock.sendMessage(jid, { 
                    text: getRateLimitMessage(sender),
                    mentions: [sender]
                });
                return true;
            }

            
            const allGroupMods = getAllGroupMods(jid);
            
            if (allGroupMods.length === 0) {
                await sock.sendMessage(jid, { text: '📭 Nenhum MOD cadastrado para este grupo!' });
                return true;
            }

            
            const modsListMessage = allGroupMods
                .map((mod, index) => {
                    
                    const typeIndicator = mod.listType === 2 ? ' 🔷' : ''; 
                    return `${index + 1}. ${mod.name} (v${mod.version}) [ID:${mod.id}]${typeIndicator}`;
                })
                .join('\n');

            await sock.sendMessage(jid, {
                text: `📋 *Lista de MODs Disponíveis*\n\n${modsListMessage}\n\n*Responda com o número do MOD que deseja ver*`
            });

            conversationState.setState(jid, 'AWAITING_MOD_SELECTION', {
                modsList: allGroupMods
            });

            return true;
        } catch (error) {
            console.error('Erro ao listar mods:', error);
            await sock.sendMessage(jid, { text: '❌ Falha ao exibir a lista de MODs!' });
            return true;
        }
    }

    
    if (text.toLowerCase() === 'mods2') {
        try {
            if (checkRateLimit(sender)) {
                await sock.sendMessage(jid, { 
                    text: getRateLimitMessage(sender),
                    mentions: [sender]
                });
                return true;
            }

            const groupMods = getGroupMods(jid, 2);
            
            if (groupMods.length === 0) {
                await sock.sendMessage(jid, { text: '📭 Nenhum MOD da lista DELTA cadastrado para este grupo!' });
                return true;
            }

            const modsListMessage = groupMods
                .map((mod, index) => `${index + 1}. ${mod.name} (v${mod.version}) [ID:${mod.id}]`)
                .join('\n');

            await sock.sendMessage(jid, {
                text: `📋 *Lista de MODs DELTA Disponíveis*\n\n${modsListMessage}\n\n*Responda com o número do MOD que deseja ver*`
            });

            conversationState.setState(jid, 'AWAITING_MOD_SELECTION', {
                modsList: groupMods,
                listType: 2
            });

            return true;
        } catch (error) {
            console.error('Erro ao listar mods2:', error);
            await sock.sendMessage(jid, { text: '❌ Falha ao exibir a lista de MODs DELTA!' });
            return true;
        }
    }

    
    if (text.toLowerCase() === '!addmodpv' && isAuthorized(sender)) {
        try {
            
            await sock.sendMessage(jid, { 
                text: `✅ @${sender.split('@')[0]} estou te enviando uma mensagem no privado para adicionar um MOD.`, 
                mentions: [sender] 
            });
            
            
            await sock.sendMessage(sender, { 
                text: `🤖 *Adicionar novo MOD para o grupo*\n\nEscolha o tipo de MOD que deseja adicionar:\n\n1️⃣ - MOD Normal\n2️⃣ - MOD (formato avançado)\n\n*Responda com o número da opção*` 
            });
            
            
            conversationState.setState(sender, 'PRIVATE_ADD_MOD_TYPE', {
                groupJid: jid,
                groupName: jid 
            });
            
            return true;
        } catch (error) {
            console.error('Erro ao iniciar adição de mod via PV:', error);
            await sock.sendMessage(jid, { text: '❌ Ocorreu um erro ao tentar iniciar a adição no privado!' });
            return true;
        }
    }

    
    if (text.toLowerCase().startsWith('!addmod') && isAuthorized(sender)) {
       
        const hasNumberEmoji = /[1-4]️⃣/.test(text);
        
        if (hasNumberEmoji) {
            try {
                
                const deltaModInfo = parseDeltaMod(text);
                
                const newMod = addMod(jid, {
                    ...deltaModInfo,
                    listType: 2,
                    addedBy: sender
                });

                await sock.sendMessage(jid, {
                    text: `✅ MOD DELTA adicionado com sucesso!\n\n📦 *${newMod.name}*\n🆔 ID: ${newMod.id}\n📱 Versão: ${newMod.version}`
                });
                return true;
            } catch (error) {
                console.error('Erro ao adicionar mod Delta:', error);
                await sock.sendMessage(jid, {
                    text: '❌ Erro ao processar o mod DELTA. Verifique o formato e tente novamente.'
                });
                return true;
            }
        } else {
            
            const parts = text.split('|').map(p => p.trim());
            if (parts.length < 3) {
                return await sock.sendMessage(jid, {
                    text: '❌ Formato incorreto! Use:\n!addmod Nome | Versão | Link\n\nExemplo:\n!addmod WhatsApp GB | 17.60 | https://exemplo.com/gb'
                });
            }

            
            if (!parts[2].startsWith('http')) {
                return await sock.sendMessage(jid, {
                    text: '❌ Link inválido! Deve começar com http:// ou https://'
                });
            }

            const newMod = addMod(jid, {
                name: parts[0].replace('!addmod', '').trim(),
                version: parts[1],
                link: parts[2],
                listType: 1,
                addedBy: sender
            });

            await sock.sendMessage(jid, {
                text: `✅ MOD adicionado com sucesso!\n\n📦 *${newMod.name}*\n🆔 ID: ${newMod.id}\n🔗 ${newMod.link}`
            });
            return true;
        }
    }

    return false;
};


const handlePrivateModConversation = async (sock, msg, jid, text) => {
    const state = conversationState.getState(jid);
    if (!state) return false;
    
    
    if (state.state === 'PRIVATE_ADD_MOD_TYPE') {
        const option = text.trim();
        
        if (option === '1' || option === '1️⃣') {
           
            await sock.sendMessage(jid, { 
                text: `📝 *Adicionar MOD Normal*\n\nPor favor, envie as informações do MOD no seguinte formato:\n\nNome | Versão | Link\n\nExemplo:\nWhatsApp GB | 17.60 | https://exemplo.com/gb` 
            });
            
            conversationState.setState(jid, 'PRIVATE_ADD_MOD_NORMAL', {
                groupJid: state.data.groupJid,
                groupName: state.data.groupName
            });
            
            return true;
        } 
        else if (option === '2' || option === '2️⃣') {
           
            await sock.sendMessage(jid, { 
                text: `📝 *Adicionar MOD Delta*\n\nPor favor, envie as informações do MOD no seguinte formato Delta:\n\nNome | Versão | Descrição\n1️⃣ Opção 1\nPackage 1\nhttps://link1.com\n\n2️⃣ Opção 2\nPackage 2\nhttps://link2.com\n\n🔰 Info extra\n®️ Autor` 
            });
            
            conversationState.setState(jid, 'PRIVATE_ADD_MOD_DELTA', {
                groupJid: state.data.groupJid,
                groupName: state.data.groupName
            });
            
            return true;
        }
        else {
            await sock.sendMessage(jid, { 
                text: '❌ Opção inválida. Por favor, responda com 1 ou 2.' 
            });
            return true;
        }
    }
    
  
    else if (state.state === 'PRIVATE_ADD_MOD_NORMAL') {
        try {
            const parts = text.split('|').map(p => p.trim());
            if (parts.length < 3) {
                await sock.sendMessage(jid, {
                    text: '❌ Formato incorreto! Use:\nNome | Versão | Link\n\nExemplo:\nWhatsApp GB | 17.60 | https://exemplo.com/gb'
                });
                return true;
            }

            
            if (!parts[2].startsWith('http')) {
                await sock.sendMessage(jid, {
                    text: '❌ Link inválido! Deve começar com http:// ou https://'
                });
                return true;
            }

            const newMod = addMod(state.data.groupJid, {
                name: parts[0].trim(),
                version: parts[1],
                link: parts[2],
                listType: 1,
                addedBy: jid
            });

            
            await sock.sendMessage(jid, {
                text: `✅ MOD adicionado com sucesso ao grupo!\n\n📦 *${newMod.name}*\n🆔 ID: ${newMod.id}\n🔗 ${newMod.link}`
            });
            
            
            await sock.sendMessage(state.data.groupJid, {
                text: `✅ Novo MOD adicionado ao grupo via PV!\n\n📦 *${newMod.name}*\n🆔 ID: ${newMod.id}\n📱 Versão: ${newMod.version}`
            });
            
            conversationState.clearState(jid);
            return true;
        } catch (error) {
            console.error('Erro ao adicionar mod normal via PV:', error);
            await sock.sendMessage(jid, {
                text: '❌ Erro ao adicionar o MOD. Tente novamente.'
            });
            return true;
        }
    }
    
    
    else if (state.state === 'PRIVATE_ADD_MOD_DELTA') {
        try {
           
            const textWithPrefix = text.toLowerCase().startsWith('!addmod') ? text : `!addmod ${text}`;
            
            
            const deltaModInfo = parseDeltaMod(textWithPrefix);
            
            const newMod = addMod(state.data.groupJid, {
                ...deltaModInfo,
                listType: 2,
                addedBy: jid
            });

            
            await sock.sendMessage(jid, {
                text: `✅ MOD DELTA adicionado com sucesso ao grupo!\n\n📦 *${newMod.name}*\n🆔 ID: ${newMod.id}\n📱 Versão: ${newMod.version}`
            });
            
            // Notificação no grupo
            await sock.sendMessage(state.data.groupJid, {
                text: `✅ Novo MOD DELTA adicionado ao grupo via PV!\n\n📦 *${newMod.name}*\n🆔 ID: ${newMod.id}\n📱 Versão: ${newMod.version}`
            });
            
            conversationState.clearState(jid);
            return true;
        } catch (error) {
            console.error('Erro ao adicionar mod Delta via PV:', error);
            await sock.sendMessage(jid, {
                text: '❌ Erro ao processar o mod DELTA. Verifique o formato e tente novamente.'
            });
            return true;
        }
    }
    
    return false;
};

module.exports = {
    handleModsCommands
};